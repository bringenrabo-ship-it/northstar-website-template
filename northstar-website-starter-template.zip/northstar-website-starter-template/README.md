# Northstar Studio — Website Starter Template

A responsive, one-page website template for a small business, NGO, initiative, personal brand, or creative studio.

## Files
- `index.html` — page content and structure
- `style.css` — layout, colours, typography, and responsive styles
- `script.js` — mobile navigation, current year, and demo enquiry form

## Preview locally
Open `index.html` in a browser. For best results, use a simple local server or deploy it to Vercel.

## Deploy using GitHub + Vercel
1. Create a new GitHub repository, e.g. `client-name-website`.
2. Upload `index.html`, `style.css`, `script.js`, and this README.
3. In Vercel, choose **Add New → Project** and import the repository.
4. Deploy. This is a static site, so no build command is required.
5. Test the live URL on a phone and computer.

## Customise before delivering
Search the files for `Northstar`, `hello@example.com`, `Your City`, and the sample copy. Replace them with the client's real brand details.
- Change the colour variables at the top of `style.css` (`--navy`, `--green`, `--cream`).
- Replace the sample project cards, descriptions, and contact details.
- Update the page title and description in `index.html`.
- Replace the sample images with client-owned images or images you have permission to use.

## About images
The template uses remote sample photos from Unsplash via image URLs. They are not included in the ZIP and need an internet connection to display. For a client site, use photos supplied by the client or appropriately licensed images. You can also download approved images and store them in an `images/` folder in the repository, then update the image paths.

## Contact form warning
The form in this template opens an email draft using `mailto:`; it does not store submissions on a server. Change `hello@example.com` in `script.js` to the client's email address. For a proper form submission workflow, connect a form provider or build a backend and test it before delivery.

## Template content
“Northstar Studio” and the project descriptions are fictional placeholder content. Replace them before publishing a client version.
